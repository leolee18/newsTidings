


   $(".header").html('');
    $(".header").html(
        '<a href="search.html"><div class="head2"></div></a>'+
        '<div class="head1"></div>'+
  '<ul class="under" style="position: absolute;top: 86px;left: 0;width: 100%;">'+
   ' <a href="index.html"><li style="width: 100%;height: 82px;background: url(images/1.jpg);"></li></a>'+
  '<li>'+
    '<p  style="width: 100%;height: 82px;background: url(images/2.jpg);"></p>'+
    '<ul class="mena1">'+
      '<li><a href="about-1.html">董事长致辞</a></li>'+
      '<li><a href="about-6.html">企业概况</a></li>'+
      '<li><a href="about-3.html">领导关怀</a></li>'+
      '<li><a href="about-5.html">企业荣誉</a></li>'+
      '<li><a href="about-4.html">企业文化</a></li>'+
      '<li><a href="about-2.html">联系我们</a></li>'+
    '</ul>'+
  '</li>'+
  '<li>'+
    '<p  style="width: 100%;height: 82px;background: url(images/3.jpg);"></p>'+
    '<ul class="mena1">'+
     ' <li><a href="newsTidings/index.html#/tab1">企业资讯</a></li>'+
      '<li><a href="newsTidings/index.html#/tab2">行业动态</a></li>'+
      '<li><a href="newsTidings/index.html#/tab3">视频专区</a></li>'+
    '</ul>'+
  '</li>'+
  '<li>'+
    '<p  style="width: 100%;height: 82px;background: url(images/4.jpg);"></p>'+
    '<ul class="mena1">'+
     ' <li><a href="chanpin-1.html">产品中心</a></li>'+
      '<li><a href="https://magu.tmall.com/">天猫旗舰</a></li>'+
    '</ul>'+
  '</li>'+
  '<li>'+
    '<p  style="width: 100%;height: 82px;background: url(images/6.jpg);"></p>'+
    '<ul class="mena1">'+
      '<li><a href="pinpai-1.html">品牌故事</a></li>'+
      '<li><a href="pinpai-2.html">神话传说</a></li>'+
     '<li><a href="pinpai-4.html">石料钩沉</a></li>'+
    '</ul>'+
  '</li>'+
  '<li>'+
    '<p  style="width: 100%;height: 82px;background: url(images/7.jpg);"></p>'+
    '<ul class="mena1">'+
      '<li><a href="shehui-1.html">食品安全</a></li>'+
     '<li><a href="shehui-2.html">公益事业</a></li>'+
      '<li><a href="shehui-3.html">农技服务</a></li>'+
   ' </ul>'+
  '</li>'+
  '<li>'+
    '<p  style="width: 100%;height: 82px;background: url(images/8.jpg);"></p>'+
   ' <ul class="mena1">'+
      '<li><a href="gonggao-3.html">通知公告</a></li>'+
      '<li><a href="gonggao-2.html">招商信息</a></li>'+
      '<li><a href="gonggao-1.html">原粮收购</a></li>'+
    '</ul>'+
  '</li>'+
  '</ul>'
        
    )
